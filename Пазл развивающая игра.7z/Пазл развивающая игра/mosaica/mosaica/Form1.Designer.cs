﻿namespace mosaica
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cartincaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.peremechatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bosstanovitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(2, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(513, 421);
            this.panel1.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(516, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cartincaToolStripMenuItem,
            this.peremechatToolStripMenuItem,
            this.bosstanovitToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            this.menuToolStripMenuItem.Click += new System.EventHandler(this.menuToolStripMenuItem_Click);
            // 
            // cartincaToolStripMenuItem
            // 
            this.cartincaToolStripMenuItem.Name = "cartincaToolStripMenuItem";
            this.cartincaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.cartincaToolStripMenuItem.Text = "Picture";
            this.cartincaToolStripMenuItem.Click += new System.EventHandler(this.cartincaToolStripMenuItem_Click);
            // 
            // peremechatToolStripMenuItem
            // 
            this.peremechatToolStripMenuItem.Name = "peremechatToolStripMenuItem";
            this.peremechatToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.peremechatToolStripMenuItem.Text = "Stir";
            this.peremechatToolStripMenuItem.Click += new System.EventHandler(this.peremechatToolStripMenuItem_Click);
            // 
            // bosstanovitToolStripMenuItem
            // 
            this.bosstanovitToolStripMenuItem.Name = "bosstanovitToolStripMenuItem";
            this.bosstanovitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.bosstanovitToolStripMenuItem.Text = "Recover";
            this.bosstanovitToolStripMenuItem.Click += new System.EventHandler(this.bosstanovitToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Собери картинку";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cartincaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem peremechatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bosstanovitToolStripMenuItem;
    }
}

